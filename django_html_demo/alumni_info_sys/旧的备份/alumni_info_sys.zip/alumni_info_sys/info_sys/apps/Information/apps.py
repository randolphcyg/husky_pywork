from django.apps import AppConfig


class InformationConfig(AppConfig):
    name = 'Information'
